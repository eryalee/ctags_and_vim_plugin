# -*- coding: gb2312 -*-
class BaseClass:
    def __init__(self):
        pass

    def help(self):abstract()
    def resolve(self, arg_log):abstract()

def abstract():
    import inspect
    caller = inspect.getouterframes(inspect.currentframe())[1][3]
    raise NotImplementedError(caller + ' must be implemented in subclass')
