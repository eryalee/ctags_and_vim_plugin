# -*- coding: gb2312 -*-
from lib import BaseClass

class demo(BaseClass.BaseClass):
    def __init__(self):
        pass

    def help(self):
        res = "demo:����һ��demo��·����/usr/share/vim/vim70/adtq/python/demo.py"
        return res

    def resolve(self,l):
        line = l[0]
        s = ""
        return s
