# -*- coding: gb2312 -*-
from lib import BaseClass
import os
import vim

class lu_ie(BaseClass.BaseClass):
    def __init__(self):
        self.tmp_path = '/var/tmp/'
        self.log_file = self.tmp_path + 'log__'
        self.result_file = self.tmp_path + 'result__'
        #���ԭ����ļ�
        f = open(self.result_file, 'w')
        f.write('')
        f.close()

        self.script = '/usr/share/vim/vim70/adtq/shell/lu_ie.sh'
        self.conf = '/usr/share/vim/vim70/adtq/conf/lu_format'
        self.cmd = 'sh ' + self.script + " " + self.log_file + " " + self.conf
        #print self.cmd


    def help(self):
        res = "****************************************\n"
        res += "lu_ie:  lu IE��־����\n\n"
        res += "****************************************\n"
        return res

    def resolve(self, arg_log):
        '''������־'''
        #�Ȱ�Ҫ��������־д���ļ�
        line = arg_log[0]
        line_array = line.split('\t')
        line_str = '\n'.join(line_array) + '\n'
        f1 = open(self.log_file, 'w')
        f1.write(line_str)
        f1.close()

        #���ýű�ִ�н���
        try:
            f = open(self.result_file, 'w')
            output = os.popen(self.cmd)
            info = self.help()
            info += output.read()
            f.write(info)
            f.close()
        except  Exception, ex:
            return Exception, ":", ex

        #��ȡ�������,����
        s = ""
        f2 = open(self.result_file, 'r')
        for line in f2:
            s += line
        f2.close()
        return s
