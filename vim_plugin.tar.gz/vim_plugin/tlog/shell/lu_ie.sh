#!/bin/bash


awk -F'\n' 'ARGIND==1{
    #print NF, $0;
    log_info[FNR] = $0;
}
ARGIND==2{
    #print NF, $0;
    format_info[FNR] = $0;
}
END{
    log_len = length(log_info);
    format_len = length(format_info);
    if (log_len != format_len){
        print "Warning!! It is not the newest! Please update!\n\n";
    }
    len = log_len < format_len ? log_len : format_len;
    #print len;
    for(i = 1; i <= len; ++i){
        if (format_info[i] == "time"){
            #print "hit time";
            log_info[i] = strftime("%Y%m%d %H:%M", log_info[i]);
        }
        str = sprintf("%d\t%-18s\t%s", i, format_info[i], log_info[i]);
        print str;
    }
    #print "END OK"
    
}' $1 $2
